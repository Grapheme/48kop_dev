<?php

return array(

	'app' => __DIR__.'/../app',
	'public' => __DIR__.'/../public/',
	'base' => __DIR__.'/..',
	'storage' => __DIR__.'/../app/storage',
);
