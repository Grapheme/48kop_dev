<?php

class CatalogsTableSeeder extends Seeder {

	public function run(){
		
	}

}