<?php

class ProductsTableSeeder extends Seeder {

	public function run(){

	}

}