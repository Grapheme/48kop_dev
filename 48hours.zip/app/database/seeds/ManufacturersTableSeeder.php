<?php

class ManufacturersTableSeeder extends Seeder {

	public function run(){

	}

}