<?php

class CategoriesGroupTableSeeder extends Seeder {

	public function run(){
		
	}

}