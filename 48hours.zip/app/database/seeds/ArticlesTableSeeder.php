<?php

class ArticlesTableSeeder extends Seeder {

	public function run(){
		
	}

}