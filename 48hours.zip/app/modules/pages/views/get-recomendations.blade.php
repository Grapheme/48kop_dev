@extends('templates.default')


@section('style')
@stop


@section('content')

    <hr/>
    <center>

    {{ $content }}

    <script src="//ulogin.ru/js/ulogin.js"></script><div id="uLogin1" data-uloginid="93adc6a7"></div>

	{{ Form::open(array('url'=>'recomendations', 'role'=>'form', 'class'=>'get-recomendations-form', 'id'=>'get-recomendations-form')) }}

    <section class="col col-12">
        <div class="well">
            <header>
                <h3>Получить рекомендации:</h3>
                <div class="welcome_msg"></div>
            </header>
            <fieldset>

                <section>
                    <label class="label">Город:</label><br/>
                    <label class="input">
                        {{ Form::select('city', array('Ростов-на-Дону'=>'Ростов-на-Дону', 'Москва'=>'Москва'), 'Ростов-на-Дону', array('class'=>'template-change', 'autocomplete'=>'off')) }} <i></i>
                    </label>
                </section>

                <section>
                    <label class="label">Интересы (теги, через запятую):</label><br/>
                    <label class="input">
                        {{ Form::textarea('tags', 'ВДВ, театр', array('class'=>'redactor redactor_150')) }}
                    </label>
                </section>

                <hr/>

                <section>
                    <label class="label">Состав семьи (теги, через запятую):</label><br/>
                    <label class="input">
                        {{ Form::textarea('family', '4-7 лет, 7-10 лет', array('class'=>'redactor redactor_150')) }}
                    </label>
                </section>

                <section>
                    <label class="label">Вкус мороженного:</label><br/>
                    <label class="input">
                        {{ Form::select('taste', array('Клубничное'=>'Клубничное', 'Шоколадное'=>'Шоколадное'), 'Клубничное', array('class'=>'template-change', 'autocomplete'=>'off')) }} <i></i>
                    </label>
                </section>

                <section>
                    <label class="label">Дата:</label><br/>
                    <label class="input">
                        {{ Form::select('date', array('2014.06.21-2014.06.22'=>'21-22 июня', '2014.07.05-2014.07.06'=>'5-6 июля'), '', array('class'=>'template-change', 'autocomplete'=>'off')) }} <i></i>
                    </label>
                </section>

            </fieldset>
            <footer>
        	    <button type="submit">Получить!</button>
            </footer>
        </div>
    </section>
    
	{{ Form::close() }}
    
    <div style="float:none;clear:both"></div>
    </center>
    <hr/>

@stop


@section('scripts')
    <script src="{{ link::path('js/system/48hours.js') }}"></script>
@stop
