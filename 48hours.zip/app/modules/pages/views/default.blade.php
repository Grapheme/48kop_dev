@extends('templates.default')


@section('style')
@stop


{{--
@section('content')
@stop
--}}


@section('scripts')
@stop