@extends('templates.default')


@section('style')
@stop


@section('content')

    {{ $content }}

    <hr/>

    Вот что мы нашли:

<?

## Лимиты на количество выводимых объектов каждого типа
$limit = array(
    'places' => 5,
    'actions' => 5,
    'advices' => 5,
    'wheretobuy' => 5,
);

#Helper::d(Input::all());

$user_data = array(
    'city'   => Input::get('city'),
    'tags'   => Input::get('tags'),
    'family' => Input::get('family'),
    'taste'  => Input::get('taste'),
    'date'   => Input::get('date'),
);

#$usi = Cookie::get("user_social_info");
$usi = @$_COOKIE["user_social_info"];
#Helper::d(json_decode($usi));
#die;

#$alltags = trim(Input::get('tags'));
$alltags = trim(
    implode(",",
        array(
            Input::get('tags'),
            Input::get('family'),
            Input::get('taste'),
        )
    )
);
#if ($alltags != '') {
    $alltags = strpos($alltags, ",") ? explode(",", $alltags) : array($alltags);
    foreach ($alltags as $t => $tag)
        $alltags[$t] = trim($tag);
#} else {
#    $alltags = array();
#}
$alltags_count = count($alltags);
#Helper::dd($alltags);

####################################################################################
### МЕСТА
####################################################################################

$objects = array(); ## Объекты
$overlap = array(); ## Совпадения тегов и интересов
## Ищем все уникальные объекты с тегом переданного города
$tags = _48hoursTag::where('module', '48hoursPlaces')
                   ->where('tag', Input::get('city'))
                   ->select('unit_id')->distinct()
                   ->get();
## Перебираем
foreach ($tags as $tag) {
    ## Получаем место по тегу
    $place = $tag->place->first();
    ## Если место не найдено (такое может быть) - пропускаем
    if(is_null($place))
        continue;
    ## Получаем ВСЕ теги объекта
    $place_tags = Tag::where('module', '48hoursPlaces')
                     ->where('unit_id', $place->id)
                     ->get();
    $place->tags = $place_tags;
    ## Пересечение тегов и интересов
    $overlap[$place->id] = 0;
    ## Ищем и подсчитываем пересечения
    foreach ($place_tags as $place_tag) {
        if ($place_tag->tag == Input::get('city'))
            continue;
        foreach ($alltags as $alltag) {
            if ($alltag == Input::get('city'))
                continue;
            if (mb_strtolower($place_tag->tag) == mb_strtolower($alltag))
                ++$overlap[$place->id];
        }
    }
    $objects[$place->id] = $place;
}
## Сортируем по убыванию
arsort($overlap);
#Helper::d($overlap);
#Helper::d($objects);

/*
## Ищем среди найденного с учетом тегов
$objects2 = array();
foreach ($objects as $o => $obj) {
    $tags2 = _48hoursTag::where('module', '48hoursPlaces')
                        ->where('unit_id', $obj->id)
                        ->whereIn('tag', $alltags)
                        ->first();
                        #->toSql();
    #Helper::d($tags2);
    if(@!$tags2->tag)
        continue;
    $objects2[] = $obj;
}
Helper::dd($objects2);
## Если есть совпадения по более строгому условию - выводим их
if (count($objects2))
    $objects = $objects2;
*/

## Если что-то нашлось - выводим
if (@count($objects)) {
    echo "<h3>Места:</h3>";
    #foreach ($objects as $place) {
    $i = 0;
    foreach ($overlap as $place_id => $count) {
        if (++$i > $limit['places'])
            break;
        $place = $objects[$place_id];
        echo "<div>";
        echo "<strong>{$place->name}</strong> (совпадений: {$count}/{$alltags_count})<i>{$place->desc}</i>";
        echo "</div><br/>";
    }
}

####################################################################################
### МЕРОПРИЯТИЯ
####################################################################################

/*
## Ищем с учетом интересов
$tags = _48hoursTag::where('module', '48hoursActions')
                   ->where('tag', Input::get('city'))
                   ->select('unit_id')->distinct()
                   ->get();
foreach ($tags as $tag) {
    $action = $tag->action->first();
    if(is_null($action))
        continue;
    $objects[] = $action;
}
#Helper::dd($objects);
*/

$objects = array(); ## Объекты
$overlap = array(); ## Совпадения тегов и интересов
## Ищем все уникальные объекты с тегом переданного города
$tags = _48hoursTag::where('module', '48hoursActions')
                   ->where('tag', Input::get('city'))
                   ->select('unit_id')->distinct()
                   ->get();
## Перебираем
foreach ($tags as $tag) {
    ## Получаем объект по тегу
    $action = $tag->action->first();
    ## Если объект не найден (такое может быть) - пропускаем
    if(is_null($action))
        continue;
    ## Получаем ВСЕ теги объекта
    $action_tags = Tag::where('module', '48hoursActions')
                     ->where('unit_id', $action->id)
                     ->get();
    $action->tags = $action_tags;
    ## Пересечение тегов и интересов
    $overlap[$action->id] = 0;
    ## Ищем и подсчитываем пересечения
    foreach ($action_tags as $action_tag) {
        if ($action_tag->tag == Input::get('city'))
            continue;
        foreach ($alltags as $alltag) {
            if ($alltag == Input::get('city'))
                continue;
            if (mb_strtolower($action_tag->tag) == mb_strtolower($alltag))
                ++$overlap[$action->id];
        }
    }
    $objects[$action->id] = $action;
}
## Сортируем по убыванию
arsort($overlap);
#Helper::d($overlap);
#Helper::d($objects);

/*
## Ищем среди найденного с учетом тегов
$objects2 = array();
foreach ($objects as $o => $obj) {
    $tags2 = _48hoursTag::where('module', '48hoursActions')
                        ->where('unit_id', $obj->id)
                        ->whereIn('tag', $alltags)
                        ->first();
                        #->toSql();
    #Helper::d($tags2);
    if(@!$tags2->tag)
        continue;
    $objects2[] = $obj;
}
## Если есть совпадения по более строгому условию - выводим их
if (count($objects2))
    $objects = $objects2;
*/

## Если что-то нашлось - выводим
if (@count($objects)) {
    echo "<h3>Мероприятия:</h3>";
    #foreach ($objects as $action) {
    $i = 0;
    foreach ($overlap as $action_id => $count) {
        if (++$i > $limit['actions'])
            break;
        $action = $objects[$action_id];
        echo "<div>";
        echo "<strong>{$action->name}</strong> (совпадений: {$count}/{$alltags_count})<i>{$action->desc}</i>";
        echo "</div><br/>";
    }
}

####################################################################################
### СОВЕТЫ
####################################################################################

$objects = array();
$overlap = array();
## Ищем только по интересам
$tags = _48hoursTag::where('module', '48hoursAdvices')
                   ->whereIn('tag', $alltags)
                   ->select('unit_id')->distinct()
                   ->get();
foreach ($tags as $tag) {
    $advice = $tag->advice->first();
    if(is_null($advice))
        continue;
    ## Получаем ВСЕ теги объекта
    $advice_tags = Tag::where('module', '48hoursAdvices')
                     ->where('unit_id', $advice->id)
                     ->get();
    $advice->tags = $advice_tags;
    ## Пересечение тегов и интересов
    $overlap[$advice->id] = 0;
    ## Ищем и подсчитываем пересечения
    foreach ($advice_tags as $advice_tag) {
        if ($advice_tag->tag == Input::get('city'))
            continue;
        foreach ($alltags as $alltag) {
            if ($alltag == Input::get('city'))
                continue;
            if (mb_strtolower($advice_tag->tag) == mb_strtolower($alltag))
                ++$overlap[$advice->id];
        }
    }
    $objects[$advice->id] = $advice;
}
#Helper::dd(DB::getQueryLog());
## Сортируем по убыванию
arsort($overlap);

## Если что-то нашлось - выводим
if (@count($objects)) {
    echo "<h3>Советы:</h3>";
    $i = 0;
    #foreach ($objects as $advice) {
    foreach ($overlap as $advice_id => $count) {
        if (++$i > $limit['advices'])
            break;
        $advice = $objects[$advice_id];
        echo "<div>";
        echo "<strong>{$advice->name}</strong> (совпадений: {$count}/{$alltags_count})<i>{$advice->desc}</i>";
        echo "</div><br/>";
    }
}

####################################################################################
### ГДЕ КУПИТЬ
####################################################################################

$objects = array();
## Ищем только по городам
$tags = _48hoursTag::where('module', '48hoursWheretobuy')
                   ->where('tag', Input::get('city'))
                   ->select('unit_id')->distinct()
                   ->get();
foreach ($tags as $tag) {
    $wheretobuy = $tag->wheretobuy->first();
    if(is_null($wheretobuy))
        continue;
    $objects[] = $wheretobuy;
}

## Если что-то нашлось - выводим
if (@count($objects)) {
    echo "<h3>Где купить?:</h3>";
    $i = 0;
    foreach ($objects as $wheretobuy) {
        if (++$i > $limit['wheretobuy'])
            break;
        echo "<div>";
        echo "<strong>{$wheretobuy->name}</strong><i>{$wheretobuy->desc}</i>";
        echo "</div><br/>";
    }
}

####################################################################################

#Helper::dd(DB::getQueryLog());

?>

@stop


@section('scripts')
@stop
