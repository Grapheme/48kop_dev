<?php

class AdminGalleriesController extends BaseController {

    public static $name = 'admin_galleries';
    public static $group = 'galleries';

    /****************************************************************************/

    ## Routing rules of module
    public static function returnRoutes($prefix = null) {
        $class = __CLASS__;
        Route::group(array('before' => 'auth', 'prefix' => $prefix), function() use ($class) {
        	Route::get($class::$group.'/manage', array('uses' => $class.'@getIndex'));
        	Route::controller($class::$group, $class);
        });
    }

    ## Shortcodes of module
    public static function returnShortCodes() {
    }

    ## Extended Form elements of module
    public static function returnExtFormElements() {

        $mod_tpl = static::returnTpl();
        $class = __CLASS__;

    	ExtForm::add(
            ## Name of element
            "gallery",
            ## Closure for templates (html-code)
            function($name = 'gallery', $value = '', $params = null) use ($mod_tpl, $class) {
                ## default template
                $tpl = "extform_gallery";
                ## custom template
                if (@$params['tpl']) {
                    $tpl = $params['tpl'];
                    unset($params['tpl']);
                }
                $gallery = $value;
                ## return view with form element
                return View::make($mod_tpl.$tpl, compact('name', 'gallery', 'params'));                
    	    },
            ## Processing results closure
            function($params) use ($mod_tpl, $class) {

                #dd($params);

                $module          = isset($params['module']) ? $params['module'] : false;
                $unit_id         = isset($params['unit_id']) ? $params['unit_id'] : false;
                $gallery_id      = isset($params['gallery_id']) ? $params['gallery_id'] : false;
                $uploaded_images = isset($params['uploaded_images']) ? $params['uploaded_images'] : false;
                $module = (string)trim($module);
                $unit_id = (int)trim($unit_id);

                ## Perform all actions for adding photos to the gallery & bind gallery to the unit_id of module
                $class::imagesToUnit($uploaded_images, $module, $unit_id, $gallery_id);
            }
        );
    }
    
    ## Actions of module (for distribution rights of users)
    public static function returnActions() {
        return array(
        	'view'   => 'Просмотр',
        	'create' => 'Создание',
        	'edit'   => 'Редактирование',
        	'delete' => 'Удаление',
        );
    }

    ## Info about module (now only for admin dashboard & menu)
    public static function returnInfo() {
        return array(
        	'name' => self::$name,
        	'group' => self::$group,
        	'title' => 'Галереи', #trans('modules.pages.menu_title'), 
        	'link' => '#',
            'class' => 'fa-picture-o', 
            'show_in_menu' => 1,
            'menu_child' => array(
                array(
                	'title' => 'Управление', #trans('modules.pages.menu_title'), 
                    'link' => self::$group,
                    'class' => 'fa-th', 
                ),
            ),
        );
    }
        
    /****************************************************************************/
    
	public function __construct(){
		
		$this->beforeFilter('galleries');
        $this->locales = Config::get('app.locales');

        View::share('module_name', self::$name);

        $this->tpl = static::returnTpl('admin');
        $this->gtpl = static::returnTpl();
        View::share('module_tpl', $this->tpl);
        View::share('module_gtpl', $this->gtpl);
	}
	
	public function getIndex(){
		
		$galleries = Gallery::orderBy('id', 'desc')->get();
		return View::make($this->tpl.'index', compact('galleries'));
	}

	public function getEdit($id){
		
		$gallery = Gallery::findOrFail($id);
		$bread = $gallery->name;
		return View::make($this->tpl.'edit', compact('gallery', 'bread'));
	}

	public function postUpload(){
		
		$file = Input::file('file');
		$id = Input::get('gallery-id');

		$rules = array(
        	'file' => 'image'
	    );
	 
	    $validation = Validator::make(array('file' => $file), $rules);
	 
	    if ($validation->fails()){
	        return Response::json('This extension is not allowed', 400);
	        exit;
	    }
 
		#$destinationPath = public_path().Config::get('app-default.galleries_photo_dir');
		#$extension =$file->getClientOriginalExtension();
		#$filename = time()."_".rand(1000,1999).".".$extension; 
		#$upload_success = Input::file('file')->move($destinationPath, $filename);

		$uploadPath = public_path().Config::get('app-default.galleries_photo_dir');
		$thumbsPath = public_path().Config::get('app-default.galleries_thumb_dir');
		if(Input::hasFile('file')):
			$fileName = time()."_".rand(1000,1999).'.'.Input::file('file')->getClientOriginalExtension();
			if(!File::exists($thumbsPath)):
				File::makeDirectory($thumbsPath,0777,TRUE);
			endif;
			$thumb_upload_success = ImageManipulation::make(Input::file('file')->getRealPath())->resize(100,100,TRUE)->save($thumbsPath.'/'.$fileName);
			$image_upload_success = ImageManipulation::make(Input::file('file')->getRealPath())->resize(800,800,TRUE)->save($uploadPath.'/'.$fileName);

			$photo = Photo::create(array(
				'name' => $fileName,
				'gallery_id' => $id,
			));
		
			return Response::json('success', 200);
		else:
			return Response::json('error', 400);
		endif;
	 
	}


	public function postAbstractupload(){

		$result = array('result' => 'error');

		if(!Input::hasFile('file')) {
			$result['desc'] = 'No input file';
	        return Response::json($result, 400);
	        exit;
		}
		
		$file = Input::file('file');
		$rules = array(
        	'file' => 'image'
	    );	 
	    $validation = Validator::make(array('file' => $file), $rules);
	    if ($validation->fails()){
	    	$result['desc'] = 'This extension is not allowed';
	        return Response::json($result, 400);
	        exit;
	    }
 
		$uploadPath = public_path().Config::get('app-default.galleries_photo_dir');
		$thumbsPath = public_path().Config::get('app-default.galleries_thumb_dir');
		$fileName = time()."_".rand(1000,1999).'.'.Input::file('file')->getClientOriginalExtension();

		if(!File::exists($thumbsPath))
			File::makeDirectory($thumbsPath,0777,TRUE);

        ## Get image width & height
        $image = ImageManipulation::make(Input::file('file')->getRealPath());
        $w = $image->width();
        $h = $image->height();

        $thumb_resize_w = ($w > $h) ? null : 200;
        $thumb_resize_h = ($w > $h) ? 200 : null;
        $image_resize_w = ($w > $h) ? null : 800;
        $image_resize_h = ($w > $h) ? 800 : null;

		$thumb_upload_success = ImageManipulation::make(Input::file('file')->getRealPath())
                                                ->resize($thumb_resize_w, $thumb_resize_h, function($constraint){
                                                    $constraint->aspectRatio();
                                                    $constraint->upsize();
                                                })
                                                ->save($thumbsPath.'/'.$fileName);

		$image_upload_success = ImageManipulation::make(Input::file('file')->getRealPath())
                                                ->resize($image_resize_w, $image_resize_h, function($constraint){
                                                    $constraint->aspectRatio();
                                                    $constraint->upsize();
                                                })
                                                ->save($uploadPath.'/'.$fileName);

		if (!$thumb_upload_success || !$image_upload_success) {
	    	$result['desc'] = 'Error on the saving images';
	        return Response::json($result, 400);
	        exit;
		}

		$gallery_id = Input::get('gallery_id') ? (int)Input::get('gallery_id') : 0;

		$photo = Photo::create(array(
			'name' => $fileName,
			'gallery_id' => $gallery_id,
		));

		$result = array('result' => 'success', 'image_id' => $photo->id);

		return Response::json($result, 200);		
	}


	public function postPhotodelete() {

		$id = (int)Input::get('id');
        if ($id)
            $model = Photo::find($id);
        if (!is_null($model))
		    $db_delete = $model->delete();

		if(@$db_delete) {
			$file_delete = File::delete(public_path().Config::get('app-default.galleries_photo_dir').'/'.$model->name);
			$thumb_delete = File::delete(public_path().Config::get('app-default.galleries_thumb_dir').'/'.$model->name);
		}

		if(@$db_delete && @$file_delete && @$thumb_delete) {
			return Response::json('success', 200);
		} else {
			return Response::json('error', 400);
		}
	}

	public function postCreate(){
		
		$input = Input::all();
		$validation = Validator::make($input, gallery::getRules());
		if($validation->fails()) {
			return Response::json($validation->messages()->toJson(), 400);
		} else {
			$id = Gallery::create($input)->id;
			$href = link::to('admin/galleries/edit/'.$id);
			return Response::json($href, 200);
		}
	}

	public function postDelete(){
		
		$id = Input::get('id');
		$gallery = Gallery::find($id);

		@Rel_mod_gallery::where('gallery_id', $gallery->id)->delete();
		$deleted = $gallery->delete();

		if($deleted) {
			return Response::json('success', 200);
		} else {
			return Response::json('error', 400);
		}
	}

	public static function moveImagesToGallery($images = array(), $gallery_id = false) {

		if ( !isset($images) || !is_array($images) || !count($images) )
			return false;

        ## Find gallery
        $gallery = $gallery_id ? Gallery::find($gallery_id) : null;

        ## If gallery not found - create her
		if (!$gallery) {
			$gallery = Gallery::create(array(
				'name' => 'noname',
			));
		}
 
        ## Get gallery ID
        $gallery_id = $gallery->id;

        ## Move all images to gallery
		foreach ($images as $i => $img_id) {
			$img = Photo::find($img_id);
			if (@$img) {
				$img->gallery_id = $gallery_id;
				#print_r($img);
				$img->save();
			}
		}

		return $gallery_id;
	}

	public static function relModuleUnitGallery($module = '', $unit_id = 0, $gallery_id = 0) {

		if ( !@$module || !$unit_id || !$gallery_id )
			return false;

		$rel = Rel_mod_gallery::where('module', $module)->where('unit_id', $unit_id)->where('gallery_id', $gallery_id)->first();

		if (!is_object($rel) || !@$rel->id) {
			$rel = Rel_mod_gallery::create(array(
				'module' => $module,
				'unit_id' => $unit_id,
				'gallery_id' => $gallery_id,
			));
		}

		$gallery = Gallery::find($gallery_id);
		$gallery->name = $module . " - " . $unit_id;
		$gallery->save();

		return $rel->id;
	}

	public static function imagesToUnit($images = array(), $module = '', $unit_id = 0, $gallery_id = false) {

		if (
			!isset($images) || !is_array($images) || !count($images)
			|| !@$module || !$unit_id
		)
			return false;

		$gallery_id = self::moveImagesToGallery($images, $gallery_id);
		self::relModuleUnitGallery($module, (int)$unit_id, $gallery_id);

		return true;
	}

}


