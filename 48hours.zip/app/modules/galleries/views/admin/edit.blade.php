@extends('templates.'.AuthAccount::getStartPage())


@section('content')
    <h1>Галерея #{{ $gallery->id }}: {{ $gallery->name }}</h1>
	@include($module_gtpl.'abstract')
	@include($module_gtpl.'uploaded')
@stop


@section('scripts')
	<!--
	<script src="{{ link::path('js/vendor/dropzone.min.js') }}"></script>
	<script src="{{ link::path('js/system/dropzone-functions.js') }}"></script>
    -->
@stop