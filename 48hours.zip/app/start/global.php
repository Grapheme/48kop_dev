<?php

/*
|--------------------------------------------------------------------------
| Register The Laravel Class Loader
|--------------------------------------------------------------------------
|
| In addition to using Composer, you may use the Laravel class loader to
| load your controllers and models. This is useful for keeping all of
| your classes in the "global" namespace without Composer updating.
|
*/


ClassLoader::addDirectories(array(

	app_path().'/commands',
	app_path().'/controllers',
	app_path().'/modules',
	app_path().'/models',
	app_path().'/database/seeds',
	app_path().'/lib',

));


/*
|--------------------------------------------------------------------------
| Application Error Logger
|--------------------------------------------------------------------------
|
| Here we will configure the error logger setup for the application which
| is built on top of the wonderful Monolog library. By default we will
| build a basic log file setup which creates a single file for logs.
|
*/

Log::useFiles(storage_path().'/logs/laravel.log');

/*
|--------------------------------------------------------------------------
| Application Error Handler
|--------------------------------------------------------------------------
|
| Here you may handle any errors that occur in your application, including
| logging them or displaying custom views for specific errors. You may
| even register several error handlers to handle different types of
| exceptions. If nothing is returned, the default error view is
| shown, which includes a detailed stack trace during debug.
|
*/

App::error(function(Exception $exception, $code)
{
	Log::error($exception);
});

/*
|--------------------------------------------------------------------------
| Maintenance Mode Handler
|--------------------------------------------------------------------------
|
| The "down" Artisan command gives you the ability to put an application
| into maintenance mode. Here, you will define what is displayed back
| to the user if maintenance mode is in effect for the application.
|
*/

App::down(function()
{
	return Response::make("Be right back!", 503);
});

/*
|--------------------------------------------------------------------------
| Require The Filters File
|--------------------------------------------------------------------------
|
| Next we will load the filters file for the application. This gives us
| a nice separate location to store our route and application filter
| definitions instead of putting them all in the main routes file.
|
*/

require app_path().'/filters.php';



/*
|--------------------------------------------------------------------------
| Переадресовываем uspensky-pk.com на немецкую версию
|--------------------------------------------------------------------------
*/

/*
    if (
        isset($_SERVER['HTTP_HOST'])
        && $_SERVER['HTTP_HOST'] != ''
        && stripos(@$_SERVER['HTTP_HOST'], ".com")
        && Request::segment(1) != 'de'
        && Session::get('locale') == ''
    ) {
    	Session::put('locale', 'de');
        Redirect("/de");
    }
*/

/*
|--------------------------------------------------------------------------
| Определяем язык сайта для всего приложения,
| a не только для роутов с фильтром i18n_url
|--------------------------------------------------------------------------
| По идее этот код должен идти ДО фильтров, но т.к. в строке выше фильтры
| только инициализируются, а запускаться будут в роутах - то можно и так.
|--------------------------------------------------------------------------
*/

/*
	Config::set('app.default_locale', Config::get('app.locale'));
    if (in_array(Request::segment(1), Config::get('app.locales')) ) {
    	Config::set('app.locale', Request::segment(1));
    }
	Session::put('locale', Config::get('app.locale'));
*/


#Event::listen('illuminate.query', function($query){ echo $query . "<br/>\n"; });

