<?php

return array(

	'name' => 'grphm',
	'email' => 'kd@grphm.com',
);