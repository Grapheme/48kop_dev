<header id="header">
	<div id="logo-group">
		<a class="logo" href="{{ url(AuthAccount::getStartPage()) }}">Панель управления</a>
	</div>
	<div class="pull-right">
		<div id="logout" class="btn-header transparent pull-right">
			<a class="logout-text" href="{{url('logout')}}" title="Завершение сеанса">Завершить сеанс</a>
		</div>
	</div>
</header>