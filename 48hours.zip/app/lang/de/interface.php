<?php 



return array(

	'MENU_INTRANET' => 'Intranet',
	'MENU_CAREER' => 'Karriere',
	'MENU_TENDERS' => 'Angebote',
	'MENU_SITEMAP' => 'Sitemap',
	'MENU_INDEX' => 'Home',
	'MENU_ABOUT' => 'Über uns',
	'MENU_NEWS' => 'Presse',
	'MENU_SERVICES' => 'Dienste',
	'MENU_INVESTORS' => 'Investors',
	'MENU_CONTACTS' => 'Kontakt',
	
	'FOOTER_COPYRIGHT' => 'Uspensker Verarbeitungs Komplex Gmbh',
    'NEWS' => 'NACHRICHTEN',
	'FOOTER_ADDRESS' => '162 Tekuchev Straße, Rostov-on-Don, Russia, 344013',
	'FOOTER_MAKEIN' => 'Made by <a href="http://grphm.com" target="_blank" class="grphm-copy">GRPHM</a>',
	
	'FORM_SIGNIN_SECURE_2_HEADER' => 'LOGIN',
	'FORM_INPUT_PLACEHOLDER_LOGIN' => 'Login',
	'FORM_INPUT_PLACEHOLDER_PASSWORD' => 'Passwot',
	'FORM_SIGNIN_SUBMIT' => 'Login',

	'PAGES_FOR_INVESTORS' => 'For investors',
	'PAGES_FOR_REQUEST_ACCESS' => 'Access to documents',

	'FORM_REQUEST_FOR_ACCESS_LABEL_FIO' => 'Kontakt Name',
	'FORM_REQUEST_FOR_ACCESS_LABEL_ORGANISATION' => 'Name der Organisation',
	'FORM_REQUEST_FOR_ACCESS_LABEL_EMAIL' => 'Email',
	'FORM_REQUEST_FOR_ACCESS_LABEL_PHONE' => 'Telefon',
	'FORM_REQUEST_FOR_ACCESS_SUBMIT' => 'Anfrage senden',
	'not_found' => 'Seite nicht gefunden',
	'back_main' => 'Zurück zur <a href=":link">Hauptseite</a>',
	'map_adress' => 'Tekucheva Straße 162<br> Rostow-am-Don',
);