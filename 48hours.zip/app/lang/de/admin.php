<?php 

return array(

	'dashboard' => 'Dashboard',
	'pages'     => 'Pages',
	'languages'     => 'Languages',
	'users'     => 'Users',
	'galleries'     => 'Galleries',
	'settings' => 'Settings',
	'editing' => 'Editing',
	'creating' => 'Creating',
	'news' => 'News',
	'articles' => 'Articles',
	'templates' => 'Templates',
	'groups' => 'Groups',
	'downloads' => 'Downloads',
	'catalog' => 'Catalog',
	'catalogs' => 'Catalogs',
	'categories' => 'Categories products',
	'products' => 'Products',
	'manufacturers' => 'Manufacturers',
);