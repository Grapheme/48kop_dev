<?php 



return array(

	'MENU_INTRANET' => 'Intranet',
	'MENU_CAREER' => 'Career',
	'MENU_TENDERS' => 'Tenders',
	'MENU_SITEMAP' => 'Sitemap',
	'MENU_INDEX' => 'Home',
	'MENU_ABOUT' => 'About us',
	'MENU_NEWS' => 'Press center',
	'MENU_SERVICES' => 'Services',
	'MENU_INVESTORS' => 'For investors',
	'MENU_CONTACTS' => 'Contacts',
	
    'NEWS' => 'News',

	'FOOTER_COPYRIGHT' => 'LLC Uspenskiy Processing Complex',
	'FOOTER_ADDRESS' => 'Russia, Rostov-on-Don, Tekucheva st., 162',
	'FOOTER_MAKEIN' => 'Made by <a href="http://grphm.com" target="_blank" class="grphm-copy">GRPHM</a>',
	
	'FORM_SIGNIN_SECURE_2_HEADER' => 'AUTHORIZATION',
	'FORM_INPUT_PLACEHOLDER_LOGIN' => 'Login',
	'FORM_INPUT_PLACEHOLDER_PASSWORD' => 'Password',
	'FORM_SIGNIN_SUBMIT' => 'Enter',

	'PAGES_FOR_INVESTORS' => 'For investors',
	'PAGES_FOR_REQUEST_ACCESS' => 'Access to documents',

	'FORM_REQUEST_FOR_ACCESS_LABEL_FIO' => 'Name of contact person',
	'FORM_REQUEST_FOR_ACCESS_LABEL_ORGANISATION' => 'Organization',
	'FORM_REQUEST_FOR_ACCESS_LABEL_EMAIL' => 'Email',
	'FORM_REQUEST_FOR_ACCESS_LABEL_PHONE' => 'Phone number',
	'FORM_REQUEST_FOR_ACCESS_SUBMIT' => 'Send request',
	'not_found' => 'Page not found',
	'back_main' => 'Back to <a href=":link">home</a> page',
	'map_adress' => 'Tekucheva street 162<br> Rostov-on-Don',
);