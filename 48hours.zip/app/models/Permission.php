<?php

class Permission extends Eloquent {
	
	protected $guarded = array();

	protected $table = 'permissions';
	
}