<?php

class Role extends Eloquent {
	
	protected $guarded = array();

	protected $table = 'roles';
	
}