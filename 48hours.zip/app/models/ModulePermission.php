<?php

class ModulePermission extends Eloquent {
	
	protected $guarded = array();

	protected $table = 'module_permissions';
	
}